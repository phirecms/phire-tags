<?php

return [
    'tags' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];