<?php

namespace Phire\Tags\Event;

use Phire\Tags\Model;
use Phire\Tags\Table;
use Pop\Application;
use Phire\Controller\AbstractController;

class Tag
{

    /**
     * Bootstrap the module
     *
     * @param  Application $application
     * @return void
     */
    public static function bootstrap(Application $application)
    {

    }

}
